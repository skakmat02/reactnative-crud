<?php

$HostName = "localhost";
$DatabaseName = "db_reactnative";
$HostUser = "root";
$HostPass = "";
